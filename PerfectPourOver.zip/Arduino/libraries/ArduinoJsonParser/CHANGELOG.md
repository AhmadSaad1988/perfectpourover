ArduinoJsonParser change log
============================

v1.2
----

* Example: changed `char[] json` into `char json[]`. Damn it C# !

v1.1
----

* Example: changed `char* json` into `char[] json` so that the bytes are not write protected
* Fixed parsing bug when the JSON contains multi-dimensional arrays

v1.0 
----

Initial release